准备将本地项目推送到 GitHub 的建议步骤（Windows PowerShell）

1. 在 GitHub 上创建新仓库（例如：`liu-xinrong-ai-projects`），不要初始化 README（或可选初始化）

2. 在本地仓库根目录（例如 `c:\Users\10300\Desktop\金木\AI\projects`）执行：

```powershell
# 进入目录
cd "c:\Users\10300\Desktop\金木\AI\projects"

# 初始化 git 仓库（若尚未）
git init

# 添加远程仓库（把 <YOUR_REMOTE_URL> 替换为 GitHub 上的新仓库 URL）
git remote add origin <YOUR_REMOTE_URL>

# 建议先添加 .gitignore（Python）
# 创建并添加文件后：
git add .

git commit -m "chore: initial commit - add project READMEs and demo notebooks"

git branch -M main

git push -u origin main
```

3. 将简历文件与英文版放入仓库（如 `projects/resume_大模型应用工程师_草稿.md` 与 `projects/resume_大模型应用工程师_English_draft.md`），并在 GitHub 仓库中把它们作为公开项目页或在 README 中链接。

4. 生成 PDF（本地）
- 若已安装 pandoc 与 wkhtmltopdf，可运行（PowerShell）：

```powershell
# 把 Markdown 转为 PDF（需要安装 pandoc）
pandoc "projects\resume_大模型应用工程师_草稿.md" -o "projects\resume_cn.pdf"

# 同样转换英文版
pandoc "projects\resume_大模型应用工程师_English_draft.md" -o "projects\resume_en.pdf"
```

5. 可选：在仓库主页添加 badge 与项目概览，上传 demo notebook 到 GitHub（.ipynb），并在 README 写明运行步骤与依赖。

---

如果你需要，我可以：
- 帮你生成 `.gitignore`（Python）并创建第一次 commit 的建议内容；
- 帮你把 README 转成更精美的 GitHub 仓库首页文案；
- 指导你如何把 notebooks 转为 HTML demo 并上传。