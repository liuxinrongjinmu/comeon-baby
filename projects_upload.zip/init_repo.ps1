# 初始化本地 git 仓库并做第一次提交（在 projects 目录下运行）
# 说明：脚本会在本地设置 user.name 与 user.email（仅针对此 repo），并提交当前文件。

param(
    [string]$CommitMessage = "chore: initial commit - add project READMEs and demo notebooks",
    [string]$UserName = "Liu Xinrong",
    [string]$UserEmail = "1030056219@qq.com"
)

Set-Location -Path $PSScriptRoot

if (-not (Test-Path .git)) {
    git init
} else {
    Write-Host "已存在 .git，执行 re-init。"
    git init
}

# 为本地仓库设置用户信息（只影响当前 repo）
git config user.name $UserName
git config user.email $UserEmail

# 添加并提交
git add .

if (git status --porcelain) {
    git commit -m $CommitMessage
    Write-Host "初始提交已完成。"
} else {
    Write-Host "没有要提交的更改（工作区干净）。"
}

Write-Host "完成：本地仓库在 $(Get-Location)"