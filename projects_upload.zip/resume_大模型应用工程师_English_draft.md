Ivan Liu (Liu Xinrong)

Phone: +86 185 9341 2520 | Email: 1030056219@qq.com | Location: Changsha, Hunan, China

Target Role: AI Application Engineer / LLM Applications Engineer

Professional Summary
Technical consultant with 8 years of SAP FICO and cross-system integration experience across 10+ ERP implementations. Strong in business requirement analysis, data modeling, ETL design, and system integration. Recently completed hands-on POCs in LLM-based retrieval (RAG), OCR + NER pipelines and time-series demand forecasting. Seeking to combine enterprise domain knowledge with large models to deliver AI-driven automation and decision-support solutions.

Core Skills
- Programming & Data: Python, SQL, Pandas, Excel automation
- ML / LLM: Retrieval-Augmented Generation (embeddings + vector DB), Prompt Engineering, basic NER/OCR pipeline design
- Data Engineering: ETL design, data cleaning, API/FS spec writing, report development
- Tools & Platforms: SAP ECC / S/4 HANA, FAISS / Chroma (example), LangChain (example), FastAPI, Docker
- Soft skills: cross-functional communication, stakeholder management, project delivery, user training

Selected Projects
- ERP Knowledge Bot (RAG) — Built a retrievable knowledge base from ERP implementation docs, SOPs and FAQs, enabling business users to query processes and get sourced answers. (projects/erp_knowledge_bot)
- Invoice & Order Data Extraction (OCR + NER) — Implemented OCR-based text extraction and rule/model-based field extraction, then matched results to SAP records for automated reconciliation. (projects/invoice_ocr_ner)
- Procurement & Inventory Demand Forecasting — Built a PoC using time-series models (Prophet) to predict short-term material demand and evaluate MAE/SMAPE improvements. (projects/demand_forecast)

Experience
Tuobao Software Co., Ltd. — SAP Finance Implementation Engineer  2023.11–Present
- Led the LTC overseas funds platform and ECC/S4 operations and transformation; responsible for requirements analysis, interface FS, and integration testing. Designed key SAP ↔ data platform interfaces supporting rollout across 14 overseas subsidiaries.
- Integrated external systems (CONCUR, e-invoice) with SAP, defined interface specifications, and implemented monitoring and alerting mechanisms.

Obvision (Aobi Zhongguang) — Digitalization Project (Shunde Factory) 2023.07–2023.11
- Drove S/4 HANA deployment for manufacturing site, designed master data governance processes and led user training; implemented FM and reporting solutions.

Education
Hunan University of Science and Technology (Xiaoxiang College) — BSc in Financial Management 2015.09–2019.06

Certifications
- SAP PA Certificate
- Junior Accountant License

Notes
- Please provide numeric values for the placeholders (e.g., percentage reductions, hours saved, document counts) and I will produce a final polished PDF/Word version and an optimized ATS-friendly layout.